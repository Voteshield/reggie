To create a new zip file easily:
`cd tests/data/west_virginia && zip -r WV-TEST.zip ./; cd -;`